import { useContext } from "react";
import '../App.css'
import { DataContext } from "./Context";




export default function Zak() {
  const context = useContext(DataContext)
  console.log(context);
  let result = context.user.gap.map((gap) => {
            let pet = GetPetById(gap.id);
        return (
        <div key={pet.id} className="block">
            <h1 className="title">{pet.name}</h1>
            <p className="text">Заказ оформлен</p>

            <p>Количество: {gap.kol}</p>
            <p className="text">
            </p>
        </div>
        );
  });

  function GetPetById(id) {
    for (let pet of context.pets) {
      if (pet.id === id) return pet;
    }
  }
  return (
    <div>
      {result}
    </div>
  );
}
