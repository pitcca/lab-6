import React from 'react'

export default function Loading() {
  return (
    <div className="load">
        <div className="ring">
            <img src="" alt="" srcset="" />
        </div>
    </div>
  )
}
