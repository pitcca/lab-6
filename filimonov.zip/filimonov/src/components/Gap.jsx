import { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { DataContext } from "./Context";





export default function Gap() {
  const context = useContext(DataContext)
  function contains(arr, elem) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i].id === elem) {
        return true;
      }
    }
    return false;
  }
  function Addzak(user) {
    let copy = Object.assign({}, user);
    console.warn(copy.gap);
    for (let elem of copy.gap) {
      copy.zak.push(elem)
    }
    copy.gap = []
    context.setUser(copy);
  }
  function DelPet(id) {
    context.setPets(
      context.pets.map((pet) => {
        if (pet.id == id && contains(context.user.gap, id)) {
          let copy = Object.assign({}, context.user);
          for (let i = 0; i < copy.gap.length; i++) {
            if (copy.gap[i].id === id) {
              copy.gap.splice(i, 1);
            }
          }
          context.setUser(copy);
        }
        return pet;
      })
    );
  }
  function setNum(num, id) {
    let copy = Object.assign({}, context.user);
    for (var i = 0; i < copy.gap.length; i++) {
      if (copy.gap[i].id === id) {
        copy.gap[i].kol = num;
      }
    }
    context.setUser(copy);}
  let result = context.user.gap.map((zak, index) => {
    let pet;
    for (var i = 0; i < context.pets.length; i++) {
      if (context.pets[i].id === zak.id) {
        console.log(context.pets, zak);
        pet = context.pets[i];
        return (
          <div key={pet.id} className="block">
            <h1 className="title">{pet.name}</h1>
            <p className="text">Статус:{pet.status}</p>
            {context.user !== null ? (
              <label htmlFor="Num">Количество: </label>
            ) : ("")}
            {context.user !== null ? (
              <input
              className="NumInput"
                id="Num"
                type="number"
                value={context.user.gap[index].kol}
                onChange={(event) => {
                  setNum(event.target.value, context.user.gap[index].id);
                }}
              />
            ) : (
              ""
            )}
            {context.user !== null ? (
              <button onClick={() => DelPet(pet.id)}>
                Удалить с корзины
              </button>
            ) : (
              ""
            )}
          </div>
        );
      }
    }
  });

  return (
    <div>
      {result}
      <Link to='/zak'><button
        onClick={() => {
          Addzak(context.user);
        }}>
        Добавить в заказ
      </button></Link>
    </div>
  );
}
