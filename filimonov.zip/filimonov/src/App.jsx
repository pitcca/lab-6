import { useEffect, useState } from 'react';
import uuid from "react-uuid";
import Reg from './components/Registration';
import Log from './components/Login';
import Gap from './components/Gap';
import Zak from './components/Zak';
import { DataContext } from './components/Context';
import Loading from './components/Loading'
import Home from './components/Home';
import './App.css';
import {BrowserRouter as  Router,
  Routes,
  Route,
  Link,
  Navigate
  } from 'react-router-dom'



function App() {
  const [pets, setPets] = useState()
  const [isLoad, setIsLoad] = useState(true)
  let initAccounts = [
    {id:1, name: 'admin', age:1, password: 'admin', gap: [], zak: []}
  ]
  const [accounts, setAccounts] = useState(initAccounts)

  const [user, setUser] = useState(null)


  async function GetPets() {
    setIsLoad(true)
    const api = await fetch('https://petstore.swagger.io/v2/pet/findByStatus?status=sold')
    const data = await api.json()
    setPets(data)
    setIsLoad(false)
    console.log(data);
  }

  useEffect(() => {
    GetPets()
  }, [])


    return <Router>
      <header className='header'>
        <nav className='menu'>
          <ul className='list'>
            <li className='elem'>{user !== null ? <p>Здравствуйте, {user.name}</p> : ''}</li>
            <li className='elem'><Link to='/' >Главная</Link></li>
            {user !== null ? <><li className='elem'><a className='logout' onClick={() => setUser(null)}>Выйти</a></li> 
            <li className='elem'><Link to='/gap'>Корзина</Link></li></> : <><li className='elem'><Link to='/reg'>Регистрация</Link></li>
            <li className='elem'><Link to='/log'>Войти</Link></li><li className='elem'><Link to='/zak'>Заказ</Link></li></>}

                
          </ul>
        </nav> 
      </header>
      <section className='container'>
      {isLoad ? <Loading/> : 
      <DataContext.Provider value={{user, setUser, accounts, setAccounts, pets}}>
        <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/reg' element={user ? <Navigate to="/" /> :  <Reg />} />
            <Route path='/log' element={user ? <Navigate to="/" /> :  <Log />} />
            <Route path='/gap'element={!user ? <Navigate to="/" /> : <Gap />} />
            <Route path='/zak'element={!user ? <Navigate to="/" /> : <Zak/>} />
      </Routes>
      </DataContext.Provider>
      }
      </section>
    </Router>  
}
export default App;
